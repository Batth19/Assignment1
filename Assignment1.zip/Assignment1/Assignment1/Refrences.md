Ref:https://www.thecanadianencyclopedia.ca/en/article/red-deer - index page
https://www.reddeer.ca/about-red-deer/history/heritage - cultural heritage history
https://www.reddeer.ca/about-red-deer/history/heritage/community-heritage-planning/red-deers-inventory-of-heritage-sites/mountview-heritage-sites-gallery/cul---horton-water-spheroid.html